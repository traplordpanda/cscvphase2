
#if !defined(_main_h)
#define _main_h

#include "usloss.h"

dynamic_dcl context finish_context;

#endif	/*  _main_h */

