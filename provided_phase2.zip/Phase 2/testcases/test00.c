
#include <stdio.h>
#include <usloss.h>
#include <phase1.h>
#include <phase2.h>

int start2(char *arg)
{

  printf("start2(): started\n");
  quit(0);
  return 0; /* so gcc will not complain about its absence... */
}
